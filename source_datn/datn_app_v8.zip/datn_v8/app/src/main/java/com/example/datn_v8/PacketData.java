package com.example.datn_v8;

public class PacketData {
    private int ID;
    private String Temperature;
    private boolean Smoke;
    private boolean Active;

    // Getters and Setters

    public int getId() {
        return ID;
    }

    public void setId(int id) {
        this.ID = id;
    }

    public String getTemperature() {
        return Temperature;
    }

    public void setTemperature(String temperature) {
        this.Temperature = temperature;
    }

    public boolean isSmoke() {
        return Smoke;
    }

    public void setSmoke(boolean smoke) {
        this.Smoke = smoke;
    }

    public boolean isActive() {
        return Active;
    }

    public void setActive(boolean active) {
        this.Active = active;
    }
    @Override
    public String toString() {
        return "PacketData{" +
                "id=" + ID +
                ", temperature=" + Temperature +
                ", smoke=" + Smoke +
                ", active=" + Active +
                '}';
    }
}
