package com.example.datn_v8;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.datn_v8.model.Node;

import java.util.List;

public class FirstFragmentViewModel extends ViewModel {
    private MutableLiveData<List<Node>> nodeList = new MutableLiveData<>();

    public LiveData<List<Node>> getNodeList() {
        return nodeList;
    }

    public void setNodeList(List<Node> nodes) {
        nodeList.setValue(nodes);
    }
}
