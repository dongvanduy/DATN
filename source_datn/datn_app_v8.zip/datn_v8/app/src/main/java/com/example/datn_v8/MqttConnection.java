package com.example.datn_v8;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
public class MqttConnection {
    private static MqttConnection instance;
    private static final String TAG = "MqttConnection";
    private static final int QOS = 2;
    private String broker = "tcp://broker.mqttdashboard.com:1883";
    private String clientId = MqttClient.generateClientId();
    private String topicNode = "duyne/node";
    private MqttAndroidClient client;
    private MqttConnectOptions options;
    private final Context context;
    private int reconnectDelay = 5000;
    private static final int MAX_RECONNECT_DELAY = 60000;

    public MqttConnection(Context context) {
        this.context = context.getApplicationContext();
        client = new MqttAndroidClient(context, broker, clientId);
        options = new MqttConnectOptions();
        options.setCleanSession(true);
        options.setAutomaticReconnect(true);
        options.setConnectionTimeout(10);
        options.setKeepAliveInterval(20);
    }

    public static synchronized MqttConnection createInstance(Context context) {
        if (instance == null) {
            instance = new MqttConnection(context);
        }
        return instance;
    }

    public String getTopicNode() {
        return topicNode;
    }

    public MqttAndroidClient getClient() {
        return client;
    }

    public void connect() {
        try {
            if (client != null && !client.isConnected()) {
                client.setCallback(mqttCallback);
                client.connect(options, null, connectActionListener);
            }
        } catch (MqttException e) {
            Log.e(TAG, "Error connecting to MQTT broker", e);
        }
    }

    public void disconnect() {
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
                client = null;
                Log.d(TAG, "Disconnected from MQTT broker");
            }
        } catch (MqttException e) {
            Log.e(TAG, "Error disconnecting from MQTT broker", e);
        }
    }

    public boolean isConnected() {
        return client != null && client.isConnected();
    }

    private void subscribeToTopics() {
        try {
            client.subscribe(topicNode, QOS);
            client.subscribe("duyne/crt", QOS);
            client.subscribe("duyne/del", QOS);
        } catch (MqttException e) {
            Log.e(TAG, "Error subscribing to topics", e);
        }
    }

    public synchronized void publishMessage(String topic, String message) {
        if (client.isConnected()) {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes(StandardCharsets.UTF_8));
            mqttMessage.setQos(QOS);
            try {
                client.publish(topic, mqttMessage);
            } catch (MqttException e) {
                Log.e(TAG, "Error publishing message to topic: " + topic, e);
            }
        }
    }

    private final MqttCallback mqttCallback = new MqttCallback() {
        @Override
        public void connectionLost(Throwable cause) {
            reconnect();
        }

        @Override
        public void messageArrived(String topic, MqttMessage message) {
//            Log.d(TAG, "Message arrived from topic: " + topic + " - Message: " + new String(message.getPayload()));
//            if (topic.equals(topicNode)) {
//                String payload = new String(message.getPayload());
//                Log.d(TAG, "Received payload: " + payload);  // In ra payload nhận được
//                PacketData packetData = new Gson().fromJson(payload, PacketData.class);
//                Log.d(TAG, "Parsed packetData: " + packetData);  // In ra packetData để kiểm tra
//                EventBus.getDefault().post(new NodeUpdatedEvent(packetData));
//            }
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {
            Log.d(TAG, "Delivery complete");
        }
    };

    private void reconnect() {
        Log.d(TAG, "Reconnecting...");
        new Handler().postDelayed(this::connect, 2000);
//        new Handler(Looper.getMainLooper()).postDelayed(() -> {
//            try {
//                if (client != null) { // Thêm kiểm tra null tại đây
//                    client.connect(options, null, connectActionListener);
//                } else {
//                    // Xử lý khi client là null (ví dụ: khởi tạo lại client)
//                    client = new MqttAndroidClient(context, broker, clientId); // Tạo lại MqttAndroidClient
//                    client.connect(options, null, connectActionListener); // Thực hiện kết nối lại
//                }
//            } catch (MqttException e) {
//                Log.e(TAG, "Error reconnecting to MQTT broker", e);
//            }
//        }, reconnectDelay);

        //reconnectDelay = Math.min(reconnectDelay * 2, MAX_RECONNECT_DELAY);
    }

    private final IMqttActionListener connectActionListener = new IMqttActionListener() {
        @Override
        public void onSuccess(IMqttToken asyncActionToken) {
            Log.d(TAG, "Connected to MQTT broker");
            subscribeToTopics();
            //reconnectDelay = 5000;
        }

        @Override
        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
            Log.e(TAG, "Failed to connect to MQTT broker: " + exception.getMessage());
            Log.e(TAG, "Detailed error: ", exception); // Thêm dòng này
            reconnect();
        }
    };

}
