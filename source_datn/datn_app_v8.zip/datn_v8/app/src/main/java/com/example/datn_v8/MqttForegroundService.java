package com.example.datn_v8;

import static com.example.datn_v8.App.CHANNEL_ID1;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.gson.Gson;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.greenrobot.eventbus.EventBus;

import java.util.Date;

public class MqttForegroundService extends Service {
    private static int NOTIFICATION_ID = 1;
    private static final String CONTENT_PUSH_NOTIFICATION = "MQTT connection is active";
    private static final String CONTENT_PUSH_TITLE = "MQTT SERVICE";
    private MqttConnection mqttConnection;
    @Override
    public void onCreate() {
        super.onCreate();
        mqttConnection = App.getMqttConnection();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!mqttConnection.isConnected()){
            mqttConnection.connect();
        }
        mqttConnection.getClient().setCallback(mqttCallback);
        Notification notification = createNotification();
        startForeground(getNotificationId(), notification);
        return START_STICKY;

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    private MqttCallback mqttCallback = new MqttCallback() {
        @Override
        public void connectionLost(Throwable cause) {
            Log.e("MQTT", "Connection lost:", cause);
            // Thử kết nối lại sau 5 giây
            new Handler().postDelayed(() -> {
                if (!mqttConnection.isConnected()) {
                    mqttConnection.connect();
                }
            }, 5000);

            // Thông báo cho người dùng (ví dụ: bằng Notification)
            //showNotification("Mất kết nối MQTT", "Đang thử kết nối lại...");

            // Cập nhật UI (gửi broadcast hoặc sử dụng EventBus)
            Intent intent = new Intent("MQTT_CONNECTION_LOST");
            LocalBroadcastManager.getInstance(MqttForegroundService.this).sendBroadcast(intent);
        }

        @Override
        public void messageArrived(@NonNull String topic, MqttMessage message) throws Exception {
            Log.d("duy foreground", "Message arrived from topic: " + topic + " -> " + new String(message.getPayload()));
            if(topic.equals(App.getMqttConnection().getTopicNode())){
                String payload = new String(message.getPayload());
                PacketData packetData = new Gson().fromJson(payload, PacketData.class);

                EventBus.getDefault().post(new NodeUpdatedEvent(packetData));

                if(packetData.isSmoke()){
                    Intent alarmIntent = new Intent("ACTION_ALARM_TRIGGERED");
                    Log.d("MQTT_FOREGROUND_SERVICE", "Phat hien co khoi!!!!");
                    LocalBroadcastManager.getInstance(MqttForegroundService.this).sendBroadcast(alarmIntent);
                }
            }

        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {
        }
    };

    private int getNotificationId(){
        return (int) new Date().getTime();
    }



    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        //Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_notification);
        //PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pendingIntent = PendingIntent.getService(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);


        NotificationCompat.Builder builder =  new NotificationCompat.Builder(this, CHANNEL_ID1)
                .setContentTitle("MQTT Service")
                .setContentText("MQTT connection is active")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH);
        return builder.build();
    }

}