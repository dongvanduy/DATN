package com.example.datn_v8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.datn_v8.model.Node;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ManagerNodes.db";
    private static final int VERSION = 1;
    private static final String TABLE_NAME = "nodes";
    private static final String COLUMN_ID = "Id";
    private static final String COLUMN_PLACE = "Place";
    private final Context context;

    public DataBaseHelper(@Nullable Context context){
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_NODES_TABLE = "CREATE TABLE nodes ( Id INTEGER PRIMARY KEY, Place VARCHAR(255))";
        db.execSQL(CREATE_NODES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public ArrayList<Node>getAllDisplays() {
        ArrayList<Node> displays = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM nodes", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int displayId = cursor.getInt(0);
            String displayPlace = cursor.getString(1);
            displays.add(new Node(displayId, displayPlace));
            cursor.moveToNext();
        }
        cursor.close();
        return displays;
    }
    public Node getDisplayById(int id){
        Node display = null;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM nodes WHERE Id = ?", new String[]{id +""});
        if(cursor.getCount()> 0){
            cursor.moveToFirst();
            int displayId = cursor.getInt(0);
            String displayPlace = cursor.getString(1);
            display = new Node(displayId, displayPlace);
        }
        cursor.close();
        return display;
    }
    public void updateDisplay(Node display){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE nodes SET Place=? WHERE Id = ?", new String[]{display.getPlace(), display.getId() + ""});

    }
    public void insertDisplay(Node display){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO nodes (Id, Place) VALUES (?,?)", new String[]{display.getId() + "", display.getPlace()});
    }
    public long addNode(int id, String place){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID, id);
        cv.put(COLUMN_PLACE, place);
        long result = db.insert(TABLE_NAME, null, cv);
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Added Successfully!!",Toast.LENGTH_SHORT).show();
        }
        db.close();
        return result;
    }
    public void deleteById(int id){
        SQLiteDatabase db = getReadableDatabase();
        db.execSQL("DELETE FROM nodes WHERE Id = ?", new String[]{String.valueOf(id)});

    }
}
