package com.example.datn_v8.fragment;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.datn_v8.App;
import com.example.datn_v8.DataBaseHelper;
import com.example.datn_v8.FirstFragmentViewModel;
import com.example.datn_v8.MainActivity;
import com.example.datn_v8.MqttConnection;
import com.example.datn_v8.NodeUpdatedEvent;
import com.example.datn_v8.PacketData;
import com.example.datn_v8.R;
import com.example.datn_v8.adapter.NodeAdapter;
import com.example.datn_v8.databinding.FragmentFirstBinding;
import com.example.datn_v8.model.Node;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private MqttConnection mqttConnection;
    private NodeAdapter nodeAdapter;
    private DataBaseHelper dataBaseHelper;
    private RecyclerView rclNode;
    private ArrayList<Node> arrListNode;
    private FirstFragmentViewModel viewModel;
    private boolean isBound = false;

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);

        rclNode = binding.rclNode;
        dataBaseHelper = new DataBaseHelper(requireContext());
        arrListNode = new ArrayList<>();
        rclNode.setLayoutManager(new LinearLayoutManager(getContext()));
        nodeAdapter = new NodeAdapter(arrListNode, getContext());
        rclNode.setAdapter(nodeAdapter);
        updateNodeList();
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = ((MainActivity) requireActivity()).getViewModel();

        //Khôi phục trạng thái Recyclerview
        if (savedInstanceState != null) {
            Parcelable recyclerViewState = savedInstanceState.getParcelable("recyclerViewState");
            rclNode.getLayoutManager().onRestoreInstanceState(recyclerViewState);

            // Khôi phục dữ liệu từ ViewModel
            ArrayList<Node> savedNodeList = savedInstanceState.getParcelableArrayList("nodeList");
            if (savedNodeList != null) {
                viewModel.setNodeList(savedNodeList);
            }
        }

        viewModel.getNodeList().observe(getViewLifecycleOwner(), nodes -> {
            arrListNode.clear();
            arrListNode.addAll(nodes);
            nodeAdapter.notifyDataSetChanged();
        });


        binding.btnFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment, null, null);
            }
        });

        //mqttConnection = MqttConnection.createInstance(requireContext());

        mqttConnection = App.getMqttConnection();

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(itemTouchHelperCallback);
        itemTouchHelper.attachToRecyclerView(rclNode);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Parcelable recyclerViewState = rclNode.getLayoutManager().onSaveInstanceState();
        outState.putParcelable("recyclerViewState", recyclerViewState);

        //Lưu dữ liệu trong ViewModel vào Bundle
        outState.putParcelableArrayList("nodeList", new ArrayList<>(viewModel.getNodeList().getValue()));
    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNodeUpdatedEvent(NodeUpdatedEvent event) {
        updateNode(event.getPacketData());//Giữ lại
    }

    public void updateNode(PacketData packetData) {
        boolean nodeExists = false;
        for (Node node : arrListNode){
            if(node.getId() == packetData.getId()){
                node.setTemperature(packetData.getTemperature() + "°C");
                node.setSmoke(packetData.isSmoke()?"Alarm": "Stable");
                node.setActive(packetData.isActive());
                nodeExists = true;
                break;
            }
        }
        nodeAdapter.notifyDataSetChanged();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    private void deleteNode(int nodeId){
        dataBaseHelper.deleteById(nodeId);
        int position = -1;
        for (int i = 0; i <arrListNode.size(); i++){
            if(arrListNode.get(i).getId() == nodeId){
                position = i;
                break;
            }
        }
        if(position != -1){
            arrListNode.remove(position);
            nodeAdapter.notifyItemRemoved(position);
        }
        mqttConnection.publishMessage("duyne/del", String.valueOf(nodeId));

    }
    public void updateNodeList(){
        new Thread(()->{
            ArrayList<Node> nodeArrayList = dataBaseHelper.getAllDisplays();
            requireActivity().runOnUiThread(()->{
                if(viewModel != null){
                    viewModel.setNodeList(nodeArrayList);
                }
            });
        }).start();
    }
    ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false; // Không hỗ trợ di chuyển item
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            int position = viewHolder.getAdapterPosition();
            Node node = arrListNode.get(position);
            deleteNode(node.getId()); // Gọi hàm deleteNode để xóa node
        }
    };
    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

}