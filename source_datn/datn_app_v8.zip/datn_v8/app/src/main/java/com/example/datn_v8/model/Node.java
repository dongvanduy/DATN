package com.example.datn_v8.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Node implements Parcelable {
    private int id; // ID của node
    private String place; // Tên địa điểm của node
    private Boolean active; // Trạng thái hoạt động (Connected/Disconnected)
    private String temperature; // Giá trị nhiệt độ
    private String smoke; // Trạng thái khói (Stable/Alarm)
    private boolean alarm = false; // Cờ báo động
    private int backgroundColor; // Màu nền của item
    private int temperatureColor; // Màu chữ của nhiệt độ
    private int smokeColor; // Màu chữ của trạng thái khói

    public Node(int id, String place) {
        this.id = id;
        this.place = place;
    }

    public Node(int id, String temperature,String smoke, Boolean active) {
        this.id = id;
        this.place = place;
        this.temperature = temperature;
        this.smoke = smoke;
        this.active = active;
    }


    public Node(Parcel in) {
        id = in.readInt();
        place = in.readString();
        byte tmpActive = in.readByte();
        active = tmpActive == 0 ? null : tmpActive == 1;
        temperature = in.readString();
        smoke = in.readString();
        alarm = in.readByte() != 0;
        backgroundColor = in.readInt();
    }

    public static final Creator<Node> CREATOR = new Creator<Node>() {
        @Override
        public Node createFromParcel(Parcel in) {
            return new Node(in);
        }

        @Override
        public Node[] newArray(int size) {
            return new Node[size];
        }
    };

    public int getId() {
        return id;
    }

    public String getPlace() {
        return place;
    }

    public Boolean getActive() {
        return active;
    }

    public String getTemperature() {
        return temperature;
    }

    public String getSmoke() {
        return smoke;
    }

    public boolean isAlarm() {
        return alarm;
    }

    public int getBackgroundColor() {
        return backgroundColor;
    }

    public int getTemperatureColor() {
        return temperatureColor;
    }

    public int getSmokeColor() {
        return smokeColor;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public void setSmoke(String smoke) {
        this.smoke = smoke;
    }

    public void setAlarm(boolean alarm) {
        this.alarm = alarm;
    }

    public void setBackgroundColor(int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public void setTemperatureColor(int temperatureColor) {
        this.temperatureColor = temperatureColor;
    }

    public void setSmokeColor(int smokeColor) {
        this.smokeColor = smokeColor;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(place);
        dest.writeByte((byte) (active == null ? 0 : active ? 1 : 2));
        dest.writeString(temperature);
        dest.writeString(smoke);
        dest.writeByte((byte) (alarm ? 1 : 0));
        dest.writeInt(backgroundColor);
    }
}
