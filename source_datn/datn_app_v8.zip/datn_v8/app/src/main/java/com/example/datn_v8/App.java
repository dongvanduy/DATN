package com.example.datn_v8;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class App extends Application {
    public static final String CHANNEL_ID1 = "CHANNEL_1";
    public static final String CHANNEL_ID2 = "CHANNEL_2";
    private static MqttConnection mqttConnection;
    public static MqttConnection getMqttConnection() {
        return mqttConnection;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        Intent serviceIntent = new Intent(this, MqttForegroundService.class);
        ContextCompat.startForegroundService(this, serviceIntent);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent serviceIntent = new Intent(App.this, MqttForegroundService.class);
                ContextCompat.startForegroundService(App.this, serviceIntent);
            }
        }, 1000); // Delay for 1 second
        createNotificationChannel();
        mqttConnection = MqttConnection.createInstance(this);
        LocalBroadcastManager.getInstance(this).registerReceiver(alarmReceiver, new IntentFilter("ACTION_ALARM_TRIGGERED"));
    }


    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.action_settings);
            String description = getString(R.string.app_name);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID1, "MQTT Service", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(description);


            CharSequence name_alarm = getString(R.string.action_settings);
            String description_alarm = getString(R.string.app_name);
            int importance_alarm = NotificationManager.IMPORTANCE_MAX;
            NotificationChannel channel_alarm = new NotificationChannel(CHANNEL_ID2, "Cảnh Báo Cháy", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(description);




            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
                notificationManager.createNotificationChannel(channel_alarm);
            }
        }
    }
    private final BroadcastReceiver alarmReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("duy", " Nhan dc nhe" + intent.getAction());
            if("ACTION_ALARM_TRIGGERED".equals(intent.getAction())){
                showAlarmNotification(context);

            }
        }
    };

    private void showAlarmNotification(Context context) {
        Log.d("duy", "goi den phan thon bao lun");
        Intent intent = new Intent(context, MainActivity.class);
        //PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        //Uri alarmSound = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.coibaochay);
        //Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_fire);

        // Tạo Notificatio
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID2)
                .setSmallIcon(R.drawable.ic_fire) // Icon của notification
                .setContentTitle("Cảnh báo cháy")
                .setContentText("Phát hiện có cháy!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true) // Tự động hủy khi người dùng chạm vào
                .setContentIntent(pendingIntent); // Mở MainActivity khi nhấn vào notification
        // Hiển thị Notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(1, builder.build());
        //có thể tùy chỉnh thêm các thuộc tính khác của notification như âm thanh, rung, đèn LED, ...
        // bằng cách sử dụng các phương thức khác của NotificationCompat.Builder.
    }
}