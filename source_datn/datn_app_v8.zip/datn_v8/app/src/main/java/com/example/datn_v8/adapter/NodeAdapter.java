package com.example.datn_v8.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.datn_v8.R;
import com.example.datn_v8.model.Node;

import java.util.ArrayList;
import java.util.List;

public class NodeAdapter extends RecyclerView.Adapter<NodeAdapter.ViewHoler> {
    private ArrayList<Node> alNode;
    private Context context;

    public NodeAdapter(ArrayList<Node> alNode, Context context) {
        this.alNode = alNode != null ? alNode : new ArrayList<>();
        this.context = context;
    }


    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_node, parent, false);
        return new ViewHoler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NodeAdapter.ViewHoler holder, int position) {
        Node node = alNode.get(position);
        holder.idNode.setText(String.valueOf(node.getId()));
        holder.nodePace.setText(String.valueOf(node.getPlace()));



        if (node.getTemperature() != null) {
            holder.temperature.setText(node.getTemperature());
        } else {
            holder.temperature.setText(""); // Hoặc bất kỳ giá trị nào khác bạn muốn hiển thị
        }

        if (node.getSmoke() != null) {
            holder.smoke.setText(node.getSmoke());
        } else {
            holder.smoke.setText(""); // Hoặc bất kỳ giá trị nào khác bạn muốn hiển thị
        }
        if (node.getActive() != null) {
            holder.active.setText(node.getActive() ? "Connected": "Disconnected");
        } else {
            holder.active.setText(""); // Hoặc bất kỳ giá trị mặc định nào khác
        }

        String temperatureString = node.getTemperature();
        if (temperatureString != null) {
            try {
                int temperature = Integer.parseInt(temperatureString.replace("°C", ""));
                if (temperature > 50 || node.getSmoke() == "Alarm" ) {
                    holder.itemBackgroud.setBackgroundResource(R.drawable.rounded_background_red);
                } else if (temperature > 20) {
                    holder.itemBackgroud.setBackgroundResource(R.drawable.rounded_background_green);
                } else {
                    holder.itemBackgroud.setBackgroundResource(R.drawable.background_item);
                }
            } catch (NumberFormatException e) {
                holder.itemBackgroud.setBackgroundResource(R.drawable.background_item);
            }
        } else {
            holder.itemBackgroud.setBackgroundResource(R.drawable.background_item);
        }

        //holder.temperature.setTextColor(node.getTemperatureColor());
        //holder.smoke.setTextColor(node.getSmokeColor());
    }

    public static class ViewHoler extends RecyclerView.ViewHolder {
        TextView nodePace, temperature, smoke, active, idNode;
        LinearLayout itemBackgroud;
        public ViewHoler(@NonNull View itemView) {
            super(itemView);
            idNode = itemView.findViewById(R.id.idNode);
            nodePace = itemView.findViewById(R.id.nodePlace);
            temperature = itemView.findViewById(R.id.tv_temperature);
            smoke = itemView.findViewById(R.id.tv_smoke);
            active = itemView.findViewById(R.id.tv_active);
            itemBackgroud = itemView.findViewById(R.id.itemBackground);
        }
    }

    public void updateItems(List<Node> newNodes) {
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override
            public int getOldListSize() {
                return alNode.size();
            }

            @Override
            public int getNewListSize() {
                return newNodes.size();
            }

            @Override
            public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                return alNode.get(oldItemPosition).getId() == newNodes.get(newItemPosition).getId(); // So sánh ID
            }

            @Override
            public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                return alNode.get(oldItemPosition).equals(newNodes.get(newItemPosition)); // So sánh toàn bộ nội dung
            }
        });

        alNode.clear();
        alNode.addAll(newNodes);
        diffResult.dispatchUpdatesTo(this); // Cập nhật RecyclerView
    }

    public int getItemCount(){
        return alNode != null? alNode.size() : 0;
    }

}
