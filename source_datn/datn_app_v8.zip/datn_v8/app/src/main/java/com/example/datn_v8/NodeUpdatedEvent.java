package com.example.datn_v8;

public class NodeUpdatedEvent {
    private PacketData packetData;
    public NodeUpdatedEvent(PacketData packetData){
        this.packetData = packetData;
    }

    public PacketData getPacketData() {
        return packetData;
    }
}
