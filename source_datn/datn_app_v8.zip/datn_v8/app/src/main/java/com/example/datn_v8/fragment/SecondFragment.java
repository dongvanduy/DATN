package com.example.datn_v8.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import com.example.datn_v8.App;
import com.example.datn_v8.DataBaseHelper;
import com.example.datn_v8.MqttConnection;
import com.example.datn_v8.R;
import com.example.datn_v8.databinding.FragmentSecondBinding;
import com.example.datn_v8.model.Node;

import java.util.List;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    public MqttConnection mqttConnection;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

//        mqttConnection = MqttConnection.createInstance(requireContext());
//        mqttConnection.connect();
        mqttConnection = App.getMqttConnection();
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        binding.btnSave.setOnClickListener(v->{
            int id = Integer.parseInt(binding.idEntry.getText().toString());
            String place = binding.placeEntry.getText().toString();

            DataBaseHelper dataBaseHelper = new DataBaseHelper(requireContext());
            long result = dataBaseHelper.addNode(id, place);
            dataBaseHelper.close();

            if(result != -1){
                if(mqttConnection.isConnected()){
                    mqttConnection.publishMessage("duyne/crt", String.valueOf(id));
                    Toast.makeText(getActivity(), "Message Add was published", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getActivity(), "Failed to connect to MQTT broker", Toast.LENGTH_SHORT).show();
                }
                FirstFragment firstFragment = (FirstFragment) requireActivity().getSupportFragmentManager().findFragmentById(R.id.FirstFragment);
                if(firstFragment != null){
                    firstFragment.updateNodeList();
                }
                //NavHostFragment.findNavController(SecondFragment.this).navigate(R.id.action_SecondFragment_to_FirstFragment);
                getParentFragmentManager().popBackStack();
            }
            else {
                //Xử lý thông báo lỗi
            }
        });



        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                NavHostFragment.findNavController(SecondFragment.this)
//                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
                getParentFragmentManager().popBackStack(); // Bật ra khỏi Back Stack
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}