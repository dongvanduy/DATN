#include "stdint.h"
#ifndef LIBS_NODELORA_H
#define LIBS_NODELORA_H

#include <Arduino.h>

class NodeLora
{
    private:
    public:
        uint8_t id;
        uint8_t error;
        uint32_t timeReceive;

        int temperatureValue;
        int smokeValue;
        int checkSum;
        
        NodeLora()
        {
            id = 0;
            error = 0;
            timeReceive = 0;
        }

        NodeLora(uint8_t _id)
        {
            id = _id;
            error = 0;
            timeReceive = 0;
        }

        NodeLora(uint8_t _id, uint32_t _timeReceive)
        {
            id = _id;
            error = 0;
            timeReceive = _timeReceive;
        }

        ~NodeLora()
        {
        } 
};


#endif