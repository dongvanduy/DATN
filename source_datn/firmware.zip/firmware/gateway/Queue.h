  #ifndef LIBS_QUEUE_H
#define LIBS_QUEUE_H

#include <Arduino.h>

template<class T>
class Queue 
{
    private:
        int _front, _back, _count;
        T *_data;
        int _maxItems;
    public:
        Queue(int maxItems = 256)
        {
            _front = 0;
            _back = 0;
            _count = 0;
            _maxItems = maxItems;
            _data = new T[maxItems + 1];
        }

        ~Queue()
        {
            delete[] _data;
        }

        inline int count();
        inline int front();
        inline int back();
        void push(const T &item);
        T peek();
        T pop();
        void clear();
};

template<class T>
inline int Queue<T>::count()
{
    return _count;
}

template<class T>
inline int Queue<T>::front()
{
    return _front;
}

template<class T>
inline int Queue<T>::back()
{
    return _back;
}

template<class T>
void Queue<T>::push(const T &item)
{
    if(_count < _maxItems) 
    {
        _data[_back++] = item;
        ++_count;
        if (_back > _maxItems)
        {
            _back -= (_maxItems + 1);
        }
        
    }
}

template<class T>
T Queue<T>::pop() {
    if(_count <= 0)
    {
        return T();
    }
    else 
    {
        T result = _data[_front];
        _front++;
        --_count;

        if (_front > _maxItems)
        {
            _front -= (_maxItems + 1);
        }
        return result;
    }
}

template<class T>
T Queue<T>::peek()
{
    if(_count <= 0)
    {
        return T();
    }
    else
    {
        return _data[_front];
    }
}

template<class T>
void Queue<T>::clear()
{
    _front = _back;
    _count = 0;
}

#endif
